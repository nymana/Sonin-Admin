var swipers = [];

$(function () {

    $('.swiper-container').each(function (index, element) {

        $(this).addClass('s' + index);

        swipers.push(new Swiper('.s' + index, {
            pagination: '.swiper-pagination',
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            slidesPerView: 1,
            loop: true,
            paginationClickable: true,
            spaceBetween: 0
        }));

    });

});