var scroll = $(window).scrollTop();
var sh = screen.height / 5;
var touchitem = null;
let isAnimating = false;
let coverDataIsReady = false;
let isWoovooCalled = false;

window.addEventListener('load', function() {
    document.body.addEventListener('touchstart', function(e) {
        if (e.changedTouches[0].target != touchitem) {
            touchitem = e.changedTouches[0].target
        }
    }, false);
}, false);

function hasscroll() {
    var wscroll = false;
    $(touchitem).parentsUntil('body').each(function(i, elem) {
        if ($(elem).hasClass('wscroll')) {
            wscroll = true;
        }
    });
    return wscroll;
}

var timer;
var medias = document.getElementsByClassName('autoplay');

Array.prototype.forEach.call(medias, function(element) {
    element.onplaying = function() { clearTimeout(timer) };
});

function woovoo() {
	isWoovooCalled = true;
    if (medias.length > 0) {

        Array.prototype.forEach.call(medias, function(element) {
            element.play();
        });

        timer = setTimeout(woovoo, 1500);
    }

    if (coverDataIsReady) {
        smoothScroll();
    }

    runAnimations();
}

function woovoo_reset() {
    clearTimeout(timer);
    var medias = document.querySelectorAll('video, audio');
    Array.prototype.forEach.call(medias, function(element) {
        element.pause();
    });
    $('.animated').addClass('anim').removeClass('animatable');
}

function runAnimations() {
    var offset = $(window).scrollTop() + $(window).height();
    $('.anim').each(function(i, elem) {
        if (($(elem).offset().top + $(elem).height() / 2) < offset) {
            var newone = $(elem).clone(true);
            newone.removeClass('anim').removeClass('animated').addClass('animated');
            $(elem).replaceWith(newone);
        }
    });
};

$(window).scroll(function() {
    runAnimations();
    if ($(window).scrollTop() >= $(document).height() - $(window).height() - 10) {
        $('.woovoo-right-arrow').css('display', 'block');
        $('.woovoo-down-arrow').css('display', 'none');
    } else {
        $('.woovoo-right-arrow').css('display', 'none');
        $('.woovoo-down-arrow').css('display', 'block');
    }

    scroll = $(window).scrollTop();

    if (scroll > sh) {
        if (!$('.fixed-title').hasClass('out')) {
            $('.fixed-title').addClass('out');
        }
    } else {
        $('.fixed-title').removeClass('out');
    }

});


$(function() {
    if ($(window).height() >= $('body').height()) {
        $('.woovoo-down-arrow').hide();
        $('.woovoo-right-arrow').show();
    } else {
        $('.woovoo-right-arrow').hide();
        $('.woovoo-down-arrow').show();
    }
    if (scroll > sh) {
        if (!$('.fixed-title').hasClass('out')) {
            $('.fixed-title').addClass('out');
        }
    }
});


$('.btn-point').on('click', function() {
    $(this).toggleClass('opened');
    parent = $(this).parent();
    parent.find('.comment').toggleClass('see');
});

//  Smooth scroll
function setSmoothScrollCover(el) {
    let rect = el.getBoundingClientRect();
    $('#smooth-scroll').css({
        width: rect.width
    });

    coverDataIsReady = true;
    if (isWoovooCalled) {
        smoothScroll();
    }
}

function smoothScroll() {
    if (isAnimating) {
        return;
    }
    isAnimating = true;

    let w = document.getElementById("cover").getBoundingClientRect();

    if (w === undefined || w === null) {
        return;
    }

    let scrollX = w.x;
    if (scrollX === 0) {
        scrollX = w.width - document.body.offsetWidth;
    } else {
        scrollX = 0;
    }

    $("html, body, #smooth-scroll").stop().animate({
        scrollLeft: scrollX
    }, 5000, function() {
        isAnimating = false;
    })
};

$(document).ready(function() {
    woovoo();
    $("#smooth-scroll").on('touchstart', function() {
        isAnimating = false;
        $("html, body, #smooth-scroll").stop();
    });
});

function setContainer(el) {
    return;
}