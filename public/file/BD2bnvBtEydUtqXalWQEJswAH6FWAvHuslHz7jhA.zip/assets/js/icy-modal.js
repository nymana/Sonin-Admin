$(document).on('keyup', function (evt) {

    if (evt.keyCode == 27) {
        $('.im-modal').removeClass('im-active');
    }

});

$('.im-modal').click(function () {

    $(this).removeClass('im-active');

}).children().click(function () {

    // stop child triggering parent click event
    return false;

});

function show_modal(id) {

    $(id).removeClass('im-active');

    $(id).addClass('im-active');

}

function close_modal() {

    $('.im-modal').removeClass('im-active');

}