

// jQuery(function($) {

// 	var doAnimations = function() {

// 		var offset = $(window).scrollTop() + $(window).height(),
// 		$animatables = $('.animatable');

// 		if ($animatables.size() == 0) {
// 			$(window).off('scroll', doAnimations);
// 		}

// 		$animatables.each(function(i) {
// 			var $animatable = $(this);
// 			if (($animatable.offset().top + $animatable.height() - 20) < offset) {
// 				$animatable.removeClass('animatable').addClass('animated');
// 			}
// 		});

// 	};

// 	$(window).on('scroll', doAnimations);
// 	$(window).trigger('scroll');
	
// });

// var timeout,
// isactive=false;

// $("img").click(function(){
// 	clearTimeout(timeout);
// 	var img = $(this),
// 	zoom = $("#zoom");
// 	zoom.css("background-image","url(" + img.attr("src") + ")" );
// 	console.log(zoom.css("background-image"));
// 	activate();
// });

// function deactivate(){
// 	$("#zoom").removeClass("active");
// 	$("body").removeClass("height100");
// 	isactive=false;
// }

// function activate(){
// 	$("#zoom").addClass("active");
// 	$("body").addClass("height100");
// 	isactive=true;
// }


// $("#zoom").click(function(){
// 	if (isactive) {
// 		deactivate();
// 	}
// });

// //magnify
// var timeo;

// function magnify(event) {
// 	clearTimeout( timeo );
// 	var x = event.touches[0].clientX,
// 	y = event.touches[0].clientY;
// 	var bx = x * 100 / $(window).width(),
// 	by = y * 100 / $(window).height();
// 	$("#zoom").css("background-size", "250%");
// 	$("#zoom").css("background-position-x", bx+"%");
// 	$("#zoom").css("background-position-y", by+"%");
// 	timeo = setTimeout( minify, 500 );
// }

// function minify(){
// 	$("#zoom").css("background-size", "contain");
// 	$("#zoom").css("background-position", "center");
// }


// $('#zoom').click(function (event) {
// 	event.stopImmediatePropagation();
// });