function expand(img_src) {
    $('#modal > div').css('background-image', 'url(' + img_src + ')');
    $('#modal').css('display', 'block');
}